import json
import os
from typing import Dict, Any

class ConfigManager:
    def __init__(self, config_dir="config"):
        self.config_dir = config_dir
        os.makedirs(config_dir, exist_ok=True)
        
        # Default configurations
        self.default_configs = {
            "app_config.json": {
                "window_size": [1200, 800],
                "default_jar_path": "",
                "default_save_folder": "",
                "default_target_folder": "",
                "batch_delay": 2,
                "theme": "clam",
                "font": {"family": "Segoe UI", "size": 9}
            },
            "proxy_config.json": {
                "test_url": "https://www.google.com",
                "timeout": 10,
                "max_threads": 5,
                "success_threshold": 200  # HTTP status code
            },
            "cloud_config.json": {
                "api_endpoint": "https://api.yourcloudservice.com/v1",
                "sync_interval": 300,  # 5 minutes
                "auth_token": ""
            },
            "finance_config.json": {
                "currency": "USD",
                "tax_rate": 0.0,
                "default_expense_categories": ["Proxy", "VPS", "Accounts", "Bonds"],
                "default_income_categories": ["Gold", "Items", "Services"]
            }
        }

    def load_config(self, config_name: str) -> Dict[str, Any]:
        """Load a configuration file"""
        config_path = os.path.join(self.config_dir, config_name)
        
        if not os.path.exists(config_path):
            self._create_default_config(config_name)
            
        try:
            with open(config_path, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return self._handle_corrupt_config(config_name)

    def save_config(self, config_name: str, config_data: Dict[str, Any]) -> None:
        """Save configuration to file"""
        config_path = os.path.join(self.config_dir, config_name)
        with open(config_path, 'w') as f:
            json.dump(config_data, f, indent=4)

    def _create_default_config(self, config_name: str) -> Dict[str, Any]:
        """Create a new config file with default values"""
        if config_name in self.default_configs:
            default_config = self.default_configs[config_name]
            self.save_config(config_name, default_config)
            return default_config
        return {}

    def _handle_corrupt_config(self, config_name: str) -> Dict[str, Any]:
        """Handle corrupt config files by recreating them"""
        print(f"Config {config_name} is corrupt, recreating with defaults")
        return self._create_default_config(config_name)
