import json
import os
from datetime import datetime

class BotListGenerator:
    def __init__(self, data_dir="data/bot_profiles"):
        self.data_dir = data_dir
        os.makedirs(data_dir, exist_ok=True)
        self.profiles_file = os.path.join(data_dir, "bot_profiles.json")
        self.status_file = os.path.join(data_dir, "bot_status.json")
        
        self.profiles = self._load_profiles()
        self.status = self._load_status()

    def _load_profiles(self):
        if os.path.exists(self.profiles_file):
            with open(self.profiles_file, 'r') as f:
                return json.load(f)
        return {}

    def _load_status(self):
        if os.path.exists(self.status_file):
            with open(self.status_file, 'r') as f:
                return json.load(f)
        return {}

    def _save_profiles(self):
        with open(self.profiles_file, 'w') as f:
            json.dump(self.profiles, f, indent=4)

    def _save_status(self):
        with open(self.status_file, 'w') as f:
            json.dump(self.status, f, indent=4)

    def add_profile(self, profile_name, proxy_info, notes=""):
        """Add a new bot profile"""
        if profile_name in self.profiles:
            return False
        
        self.profiles[profile_name] = {
            "proxy": proxy_info,
            "notes": notes,
            "created": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        self.status[profile_name] = {
            "status": "inactive",
            "last_active": None,
            "banned": False,
            "issues": []
        }
        
        self._save_profiles()
        self._save_status()
        return True

    def update_status(self, profile_name, status, is_banned=False, issue=""):
        """Update profile status"""
        if profile_name not in self.status:
            return False
        
        self.status[profile_name]["status"] = status
        self.status[profile_name]["last_active"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.status[profile_name]["banned"] = is_banned
        
        if issue:
            self.status[profile_name]["issues"].append({
                "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "issue": issue
            })
        
        self._save_status()
        return True

    def get_all_profiles(self):
        """Get all profiles with their status"""
        return {
            name: {
                **self.profiles[name],
                **self.status[name]
            } for name in self.profiles
        }

    def export_to_csv(self, file_path):
        """Export profiles to CSV"""
        import csv
        try:
            with open(file_path, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    "Profile Name", "Proxy", "Status", "Banned", 
                    "Last Active", "Created", "Notes"
                ])
                
                for name, data in self.get_all_profiles().items():
                    writer.writerow([
                        name,
                        data['proxy'],
                        data['status'],
                        "Yes" if data['banned'] else "No",
                        data['last_active'] or "Never",
                        data['created'],
                        data['notes']
                    ])
            return True
        except Exception as e:
            return False
