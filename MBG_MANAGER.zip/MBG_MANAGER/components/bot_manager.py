import psutil
import subprocess
from datetime import datetime
import os
import json
import re
from typing import Dict, Any, List, Union, Optional, Tuple
import signal
import logging

logger = logging.getLogger(__name__)

class BotManager:
    def __init__(self, data_dir: str = "data/bot_processes"):
        """Initialize the BotManager with process tracking and anti-crash capabilities."""
        try:
            self.data_dir = data_dir
            os.makedirs(data_dir, exist_ok=True)
            self.processes_file = os.path.join(data_dir, "active_processes.json")
            self.anti_crash_file = os.path.join(data_dir, "anti_crash.json")
            self.debug_log = os.path.join(data_dir, "debug.log")
            
            self.java_executables = ['java.exe', 'javaw.exe', 'java', 'javaw']
            self.bot_processes = {}
            self.anti_crash_enabled = {}
            
            try:
                self.bot_processes = self._load_processes()
                self.anti_crash_enabled = self._load_anti_crash()
            except Exception as e:
                logger.error(f"Error loading existing processes: {str(e)}")
                self.bot_processes = {}
                self.anti_crash_enabled = {}
            
            try:
                with open(self.debug_log, 'w') as f:
                    f.write(f"Bot Manager Initialized at {datetime.now()}\n")
            except Exception as e:
                logger.error(f"Could not initialize debug log: {str(e)}")
                
            logger.info("BotManager initialized successfully")
            
        except Exception as e:
            logger.critical(f"Failed to initialize BotManager: {str(e)}")
            raise

    def remove_bot(self, process_id: Union[str, int]) -> Tuple[bool, str]:
        """
        Remove a bot from monitoring.
        
        Args:
            process_id: PID of the process to remove
            
        Returns:
            Tuple of (success, message)
        """
        pid = str(process_id)
        if pid in self.bot_processes:
            try:
                # Try to stop the process first if it's running
                if self.bot_processes[pid]["status"] == "running":
                    try:
                        process = psutil.Process(int(pid))
                        process.terminate()
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        pass
                
                # Remove from tracking
                del self.bot_processes[pid]
                if pid in self.anti_crash_enabled:
                    del self.anti_crash_enabled[pid]
                
                self._save_processes()
                self._log_debug(f"Removed bot from monitoring - PID: {pid}")
                return True, "Bot removed from monitoring"
            except Exception as e:
                self._log_debug(f"Error removing bot PID {pid}: {str(e)}")
                return False, str(e)
        return False, "Process not found in manager"

    def _log_debug(self, message: str):
        """Log debug messages to file with timestamp"""
        try:
            with open(self.debug_log, 'a') as f:
                f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {message}\n")
        except Exception as e:
            logger.error(f"Error writing to debug log: {str(e)}")

    def _load_processes(self) -> Dict[str, Any]:
        """Load tracked processes from file"""
        try:
            if os.path.exists(self.processes_file):
                with open(self.processes_file, 'r') as f:
                    return json.load(f)
            return {}
        except Exception as e:
            self._log_debug(f"Error loading processes: {str(e)}")
            return {}

    def _load_anti_crash(self) -> Dict[str, bool]:
        """Load anti-crash settings from file"""
        try:
            if os.path.exists(self.anti_crash_file):
                with open(self.anti_crash_file, 'r') as f:
                    return json.load(f)
            return {}
        except Exception as e:
            self._log_debug(f"Error loading anti-crash: {str(e)}")
            return {}

    def _save_processes(self):
        """Save current process and anti-crash data to files"""
        try:
            with open(self.processes_file, 'w') as f:
                json.dump(self.bot_processes, f, indent=4)
            with open(self.anti_crash_file, 'w') as f:
                json.dump(self.anti_crash_enabled, f, indent=4)
        except Exception as e:
            self._log_debug(f"Error saving processes: {str(e)}")

    def scan_running_bots(self, jar_name: str) -> int:
        """Scan for running bot processes with multiple detection methods."""
        self._log_debug(f"Starting scan for JAR: {jar_name}")
        found_processes = {}
        
        for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'exe', 'create_time', 'username', 'cwd']):
            try:
                proc_info = proc.info
                pid = str(proc_info['pid'])
                proc_name = proc_info['name'].lower()
                cmdline = ' '.join(proc_info['cmdline']) if proc_info['cmdline'] else ""
                exe_path = proc_info.get('exe', '').lower()
                cwd = proc_info.get('cwd', '')
                
                is_java = any(java_exe in proc_name for java_exe in self.java_executables)
                jar_match = jar_name.lower() in proc_name.lower() or jar_name.lower() in cmdline.lower()
                is_bot = self._is_bot_process(cmdline)
                
                if jar_match or (is_java and is_bot):
                    profile = self._extract_profile(cmdline)
                    process_details = {
                        "profile": profile,
                        "cmdline": cmdline,
                        "start_time": datetime.fromtimestamp(proc_info['create_time']).isoformat(),
                        "status": "running",
                        "restarts": 0,
                        "last_checked": datetime.now().isoformat(),
                        "detected": True,
                        "username": proc_info.get('username', 'unknown'),
                        "executable": proc_name,
                        "exe_path": exe_path,
                        "working_dir": cwd,
                        "type": "specific_jar" if jar_match else "java_process"
                    }
                    
                    if pid not in self.bot_processes:
                        self.bot_processes[pid] = process_details
                        self.anti_crash_enabled[pid] = False
                    else:
                        self.bot_processes[pid].update(process_details)
                    
                    found_processes[pid] = True

            except (psutil.NoSuchProcess, psutil.AccessDenied, AttributeError) as e:
                continue

        self._update_process_status(found_processes)
        self._save_processes()
        return len(found_processes)

    def _is_bot_process(self, cmdline: str) -> bool:
        """Determine if a process is likely a bot based on command line."""
        bot_indicators = [
            '-jar', '--jar', 'bot', 'client',
            '-profile', '--profile', '-proxy', '--proxy',
            'main', 'run'
        ]
        cmdline_lower = cmdline.lower()
        return any(indicator in cmdline_lower for indicator in bot_indicators)

    def _extract_profile(self, cmdline: str) -> str:
        """Extract profile name from command line."""
        profile_match = re.search(r'-profile[= ]([^\s]+)', cmdline, re.IGNORECASE)
        if profile_match:
            return profile_match.group(1).strip()
        
        profile_match = re.search(r'--profile[= ]([^\s]+)', cmdline, re.IGNORECASE)
        if profile_match:
            return profile_match.group(1).strip()
            
        unique_parts = [part for part in cmdline.split() 
                       if len(part) > 6 
                       and not part.startswith('-')
                       and not part.endswith('.jar')]
        if unique_parts:
            return unique_parts[0][:20]
            
        return "default"

    def _update_process_status(self, found_processes: Dict[str, bool]):
        """Update status of all tracked processes."""
        current_time = datetime.now()
        for pid in list(self.bot_processes.keys()):
            if pid not in found_processes:
                try:
                    if not psutil.pid_exists(int(pid)):
                        self.bot_processes[pid]["status"] = "stopped"
                except ValueError:
                    continue
            elif self.bot_processes[pid]["status"] != "running":
                self.bot_processes[pid]["status"] = "running"

            self.bot_processes[pid]["last_checked"] = current_time.isoformat()

    def start_bot(self, bat_file: str, profile_name: str) -> Tuple[bool, Union[str, int]]:
        """Start a bot process from a batch file."""
        try:
            if not os.path.exists(bat_file):
                return False, f"Batch file not found: {bat_file}"
                
            process = subprocess.Popen(
                ['cmd', '/c', bat_file],
                creationflags=subprocess.CREATE_NEW_CONSOLE,
                cwd=os.path.dirname(bat_file))
            
            pid = str(process.pid)
            self.bot_processes[pid] = {
                "profile": profile_name,
                "bat_file": bat_file,
                "start_time": datetime.now().isoformat(),
                "status": "running",
                "restarts": 0,
                "last_checked": datetime.now().isoformat(),
                "detected": False,
                "username": os.getlogin(),
                "executable": "cmd.exe",
                "exe_path": "C:\\Windows\\System32\\cmd.exe",
                "working_dir": os.path.dirname(bat_file),
                "type": "bat_file"
            }
            self.anti_crash_enabled[pid] = False
            self._save_processes()
            return True, pid
            
        except Exception as e:
            self._log_debug(f"Error starting bot: {str(e)}")
            return False, str(e)

    def stop_bot(self, process_id: Union[str, int], manual_stop: bool = False) -> Tuple[bool, str]:
        """Stop a bot process."""
        pid = str(process_id)
        if pid not in self.bot_processes:
            return False, "Process not found in manager"
            
        try:
            process = psutil.Process(int(pid))
            self.bot_processes[pid]["status"] = "stopped_manually" if manual_stop else "stopped"
            self.bot_processes[pid]["last_checked"] = datetime.now().isoformat()
            
            process.terminate()
            try:
                process.wait(timeout=5)
            except (psutil.TimeoutExpired, psutil.NoSuchProcess):
                try:
                    process.kill()
                except psutil.NoSuchProcess:
                    pass
            
            self._save_processes()
            return True, "Process stopped"
            
        except psutil.NoSuchProcess:
            if pid in self.bot_processes:
                self.bot_processes[pid]["status"] = "stopped"
                self._save_processes()
            return False, "Process not found"
        except Exception as e:
            self._log_debug(f"Error stopping bot PID {pid}: {str(e)}")
            return False, str(e)

    def restart_bot(self, process_id: Union[str, int]) -> Tuple[bool, Union[str, int]]:
        """Restart a bot process."""
        pid = str(process_id)
        if pid not in self.bot_processes:
            return False, "Process not found"
            
        process_info = self.bot_processes[pid]
        
        try:
            if "bat_file" in process_info and os.path.exists(process_info["bat_file"]):
                self.stop_bot(pid)
                return self.start_bot(process_info["bat_file"], process_info["profile"])
                
            elif "cmdline" in process_info:
                cmdline = process_info["cmdline"].split()
                self.stop_bot(pid)
                process = subprocess.Popen(cmdline)
                new_pid = str(process.pid)
                
                self.bot_processes[new_pid] = {
                    "profile": process_info["profile"],
                    "cmdline": ' '.join(cmdline),
                    "start_time": datetime.now().isoformat(),
                    "status": "running",
                    "restarts": process_info.get("restarts", 0) + 1,
                    "last_checked": datetime.now().isoformat(),
                    "detected": True,
                    "username": process_info.get("username", "unknown"),
                    "executable": process_info.get("executable", "java"),
                    "exe_path": process_info.get("exe_path", ""),
                    "working_dir": process_info.get("working_dir", ""),
                    "type": "java_process"
                }
                self.anti_crash_enabled[new_pid] = self.anti_crash_enabled.get(pid, False)
                
                del self.bot_processes[pid]
                if pid in self.anti_crash_enabled:
                    del self.anti_crash_enabled[pid]
                
                self._save_processes()
                return True, new_pid
                
            else:
                return False, "No startup information available"
                
        except Exception as e:
            self._log_debug(f"Error restarting bot PID {pid}: {str(e)}")
            return False, str(e)

    def toggle_anti_crash(self, process_id: Union[str, int]) -> Tuple[bool, str]:
        """Toggle anti-crash for a bot process."""
        pid = str(process_id)
        if pid in self.anti_crash_enabled:
            self.anti_crash_enabled[pid] = not self.anti_crash_enabled[pid]
            self._save_processes()
            status = "enabled" if self.anti_crash_enabled[pid] else "disabled"
            return True, f"Anti-crash {status}"
        return False, "Process not found"

    def get_bot_status(self, process_id: Union[str, int]) -> Optional[Dict[str, Any]]:
        """Get detailed status of a bot process."""
        pid = str(process_id)
        if pid not in self.bot_processes:
            return None
            
        try:
            process = psutil.Process(int(pid))
            proc_info = self.bot_processes[pid]
            
            start_time = datetime.fromisoformat(proc_info["start_time"])
            uptime = str(datetime.now() - start_time).split('.')[0]
            cpu_percent = process.cpu_percent(interval=0.1)
            mem_mb = process.memory_info().rss / (1024 * 1024)
            
            status = proc_info["status"]
            if status == "running" and not process.is_running():
                status = "crashed"
                proc_info["status"] = status
                self._save_processes()
            
            return {
                "pid": pid,
                "profile": proc_info["profile"],
                "status": status,
                "uptime": uptime,
                "cpu": f"{cpu_percent:.1f}%",
                "memory": f"{mem_mb:.1f} MB",
                "restarts": proc_info.get("restarts", 0),
                "anti_crash": self.anti_crash_enabled.get(pid, False),
                "detected": proc_info.get("detected", False),
                "username": proc_info.get("username", "unknown"),
                "executable": proc_info.get("executable", ""),
                "working_dir": proc_info.get("working_dir", ""),
                "type": proc_info.get("type", "unknown")
            }
            
        except psutil.NoSuchProcess:
            self.bot_processes[pid]["status"] = "crashed"
            self._save_processes()
            return {
                "pid": pid,
                "profile": self.bot_processes[pid]["profile"],
                "status": "crashed",
                "uptime": "N/A",
                "cpu": "0%",
                "memory": "0 MB",
                "restarts": self.bot_processes[pid].get("restarts", 0),
                "anti_crash": self.anti_crash_enabled.get(pid, False),
                "detected": self.bot_processes[pid].get("detected", False),
                "username": self.bot_processes[pid].get("username", "unknown"),
                "executable": self.bot_processes[pid].get("executable", ""),
                "working_dir": self.bot_processes[pid].get("working_dir", ""),
                "type": self.bot_processes[pid].get("type", "unknown")
            }
        except Exception as e:
            return {"pid": pid, "error": str(e)}

    def get_all_processes(self) -> Dict[str, Dict[str, Any]]:
        """Get status of all tracked bot processes."""
        return {pid: self.get_bot_status(pid) for pid in self.bot_processes.keys()}

    def get_all_java_processes(self) -> List[Dict[str, Any]]:
        """Get all running Java processes with detailed information."""
        java_processes = []
        for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'exe', 'create_time', 'username', 'cwd']):
            try:
                proc_info = proc.info
                if any(java_exe in proc_info['name'].lower() for java_exe in self.java_executables):
                    java_processes.append({
                        "pid": proc_info['pid'],
                        "name": proc_info['name'],
                        "cmdline": ' '.join(proc_info['cmdline']) if proc_info['cmdline'] else "",
                        "exe_path": proc_info.get('exe', ''),
                        "working_dir": proc_info.get('cwd', ''),
                        "username": proc_info.get('username', 'unknown'),
                        "create_time": datetime.fromtimestamp(proc_info['create_time']).isoformat(),
                        "is_bot": self._is_bot_process(' '.join(proc_info['cmdline']) if proc_info['cmdline'] else ""),
                        "is_tracked": str(proc_info['pid']) in self.bot_processes
                    })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return java_processes

    def cleanup_stopped_processes(self) -> int:
        """Remove entries for processes that have been stopped for a while."""
        now = datetime.now()
        removed = 0
        
        for pid in list(self.bot_processes.keys()):
            try:
                status = self.bot_processes[pid].get("status", "")
                last_checked = datetime.fromisoformat(self.bot_processes[pid]["last_checked"])
                
                if status in ["stopped", "stopped_manually", "crashed", "failed_to_restart"] and \
                   (now - last_checked).total_seconds() > 86400:
                    del self.bot_processes[pid]
                    if pid in self.anti_crash_enabled:
                        del self.anti_crash_enabled[pid]
                    removed += 1
            except (KeyError, ValueError):
                continue
        
        if removed > 0:
            self._save_processes()
        
        return removed

    def monitor_processes(self):
        """Monitor all bot processes and handle crashes if anti-crash is enabled"""
        for pid in list(self.bot_processes.keys()):
            status = self.get_bot_status(pid)
            
            if status and status.get("status") == "crashed":
                if self.anti_crash_enabled.get(pid, False):
                    self.bot_processes[pid]["restarts"] = self.bot_processes[pid].get("restarts", 0) + 1
                    success, result = self.restart_bot(pid)
                    if not success:
                        self.bot_processes[pid]["status"] = "failed_to_restart"
                else:
                    self.bot_processes[pid]["status"] = "crashed"
                
            if pid in self.bot_processes:
                self.bot_processes[pid]["last_checked"] = datetime.now().isoformat()
        
        self._save_processes()

    def get_detection_debug_info(self) -> str:
        """Get the contents of the debug log."""
        try:
            with open(self.debug_log, 'r') as f:
                return f.read()
        except Exception as e:
            return f"Error reading debug log: {str(e)}"

    def debug_scan(self) -> Dict[str, Any]:
        """Perform a debug scan and return comprehensive information."""
        all_java = self.get_all_java_processes()
        detected_bots = [{
            "pid": proc['pid'],
            "name": proc['name'],
            "cmdline": proc['cmdline'],
            "reason": "Bot indicators found in command line",
            "is_tracked": proc['is_tracked']
        } for proc in all_java if proc['is_bot']]
        
        return {
            "all_java_processes": all_java,
            "detected_bots": detected_bots,
            "currently_tracked": list(self.bot_processes.keys()),
            "debug_log": self.get_detection_debug_info(),
            "timestamp": datetime.now().isoformat()
        }
