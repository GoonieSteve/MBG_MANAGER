import json
import os
import paramiko
from datetime import datetime

class CloudIntegration:
    def __init__(self, config_dir="config", data_dir="data/cloud_connections"):
        self.config_dir = config_dir
        self.data_dir = data_dir
        os.makedirs(data_dir, exist_ok=True)
        
        self.connections_file = os.path.join(data_dir, "connections.json")
        self.connections = self._load_connections()
        
        # Initialize SSH client
        self.ssh = paramiko.SSHClient()
        self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    def _load_connections(self):
        if os.path.exists(self.connections_file):
            with open(self.connections_file, 'r') as f:
                return json.load(f)
        return []

    def _save_connections(self):
        with open(self.connections_file, 'w') as f:
            json.dump(self.connections, f, indent=4)

    def add_connection(self, name, host, username, password=None, key_path=None, port=22):
        """Add a new cloud server connection"""
        if any(conn['name'] == name for conn in self.connections):
            return False, "Connection with this name already exists"
        
        connection = {
            "name": name,
            "host": host,
            "username": username,
            "password": password,
            "key_path": key_path,
            "port": port,
            "last_connected": None,
            "status": "disconnected"
        }
        
        self.connections.append(connection)
        self._save_connections()
        return True, "Connection added successfully"

    def connect(self, connection_name):
        """Connect to a cloud server"""
        connection = next((c for c in self.connections if c['name'] == connection_name), None)
        if not connection:
            return False, "Connection not found"
        
        try:
            if connection['key_path']:
                self.ssh.connect(
                    connection['host'],
                    port=connection['port'],
                    username=connection['username'],
                    key_filename=connection['key_path']
                )
            else:
                self.ssh.connect(
                    connection['host'],
                    port=connection['port'],
                    username=connection['username'],
                    password=connection['password']
                )
            
            # Update connection status
            connection['last_connected'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            connection['status'] = "connected"
            self._save_connections()
            
            return True, "Connected successfully"
        except Exception as e:
            return False, str(e)

    def disconnect(self):
        """Disconnect from current server"""
        try:
            self.ssh.close()
            return True, "Disconnected successfully"
        except Exception as e:
            return False, str(e)

    def execute_command(self, command):
        """Execute a command on the connected server"""
        try:
            stdin, stdout, stderr = self.ssh.exec_command(command)
            output = stdout.read().decode()
            error = stderr.read().decode()
            return True, output if not error else error
        except Exception as e:
            return False, str(e)

    def get_server_status(self):
        """Get basic server status"""
        success, result = self.execute_command("uptime && free -h && df -h")
        return success, result if success else "Not connected"

    def upload_file(self, local_path, remote_path):
        """Upload a file to the server"""
        try:
            sftp = self.ssh.open_sftp()
            sftp.put(local_path, remote_path)
            sftp.close()
            return True, "File uploaded successfully"
        except Exception as e:
            return False, str(e)

    def download_file(self, remote_path, local_path):
        """Download a file from the server"""
        try:
            sftp = self.ssh.open_sftp()
            sftp.get(remote_path, local_path)
            sftp.close()
            return True, "File downloaded successfully"
        except Exception as e:
            return False, str(e)
