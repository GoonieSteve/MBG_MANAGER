import os
import subprocess
import time

class BatchExecutor:
    def execute_batch_files(self, target_folder, bat_files, delay=2):
        """Execute all batch files in the target folder with specified delay"""
        for filename in bat_files:
            if filename.endswith(".bat"):
                filepath = os.path.join(target_folder, filename)
                try:
                    subprocess.Popen(f'start /min "" "{filepath}"', shell=True)
                    time.sleep(delay)
                except Exception as e:
                    print(f"Error executing {filename}: {str(e)}")
