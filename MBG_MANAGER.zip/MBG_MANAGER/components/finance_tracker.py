import json
import os
from datetime import datetime, timedelta
import pandas as pd
from tkinter import messagebox
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from collections import defaultdict
import calendar
from fpdf import FPDF
import seaborn as sns

class FinanceTracker:
    def __init__(self, data_dir="data/financial_records"):
        self.data_dir = data_dir
        os.makedirs(data_dir, exist_ok=True)
        
        # File paths
        self.transactions_file = os.path.join(data_dir, "transactions.json")
        self.categories_file = os.path.join(data_dir, "categories.json")
        self.tax_categories_file = os.path.join(data_dir, "tax_categories.json")
        self.reports_dir = os.path.join(data_dir, "reports")
        os.makedirs(self.reports_dir, exist_ok=True)
        
        # Initialize data structures
        self._init_files()
        self.transactions = self._load_transactions()
        self._categories = self._load_categories()
        self.tax_categories = self._load_tax_categories()
        
        # Configure visualization style
        sns.set_style("whitegrid")
        plt.rcParams['figure.autolayout'] = True

    def _init_files(self):
        """Initialize data files with defaults if they don't exist"""
        # Transactions file
        if not os.path.exists(self.transactions_file):
            with open(self.transactions_file, 'w') as f:
                json.dump([], f)
        
        # Categories file
        if not os.path.exists(self.categories_file):
            default_categories = {
                "expense": ["Proxy", "VPS", "Accounts", "Bonds", "Software", "Misc"],
                "income": ["Gold", "Items", "Services", "Other"]
            }
            with open(self.categories_file, 'w') as f:
                json.dump(default_categories, f)
        
        # Tax categories file
        if not os.path.exists(self.tax_categories_file):
            default_tax_categories = {
                "deductible": ["Proxy", "VPS", "Software"],
                "non_deductible": ["Accounts", "Bonds", "Misc"],
                "taxable": ["Gold", "Items", "Services", "Other"]
            }
            with open(self.tax_categories_file, 'w') as f:
                json.dump(default_tax_categories, f)

    def _load_transactions(self):
        """Load transactions from JSON file"""
        try:
            with open(self.transactions_file, 'r') as f:
                transactions = json.load(f)
                if transactions and isinstance(transactions, dict):
                    return list(transactions.values())
                return transactions
        except (json.JSONDecodeError, FileNotFoundError):
            return []

    def _load_categories(self):
        """Load categories from JSON file"""
        try:
            with open(self.categories_file, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return {"expense": [], "income": []}

    def _load_tax_categories(self):
        """Load tax categories from JSON file"""
        try:
            with open(self.tax_categories_file, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return {"deductible": [], "non_deductible": [], "taxable": []}

    @property
    def categories(self):
        """Get all categories"""
        return self._categories

    def get_categories(self, category_type=None):
        """Get categories with optional filtering by type"""
        if category_type:
            return self._categories.get(category_type, [])
        return self._categories

    def _save_transactions(self):
        """Save transactions to file"""
        try:
            with open(self.transactions_file, 'w') as f:
                json.dump(self.transactions, f, indent=4)
        except Exception as e:
            messagebox.showerror("Save Error", f"Failed to save transactions: {str(e)}")

    def add_transaction(self, transaction_type, amount, category, description="", date=None, tax_notes=""):
        """Add a new financial transaction with enhanced fields"""
        try:
            # Validate input
            if transaction_type not in ["income", "expense"]:
                return False, "Transaction type must be 'income' or 'expense'"
            
            if category not in self._categories[transaction_type]:
                return False, f"Invalid category for {transaction_type}"
            
            amount = float(amount)
            if amount <= 0:
                return False, "Amount must be positive"
            
            # Create comprehensive transaction record
            transaction = {
                "id": len(self.transactions) + 1,
                "date": date if date else datetime.now().strftime("%Y-%m-%d"),
                "type": transaction_type,
                "amount": amount,
                "category": category,
                "description": description,
                "tax_notes": tax_notes,
                "tax_category": self._get_tax_category(category),
                "timestamp": datetime.now().isoformat()
            }
            
            # Add to transactions and save
            self.transactions.append(transaction)
            self._save_transactions()
            
            return True, transaction
        except ValueError as e:
            return False, str(e)
        except Exception as e:
            return False, f"Failed to add transaction: {str(e)}"

    def _get_tax_category(self, category):
        """Determine tax category for a given transaction category"""
        for tax_type, categories in self.tax_categories.items():
            if category in categories:
                return tax_type
        return "uncategorized"

    def edit_transaction(self, transaction_id, **kwargs):
        """Edit an existing transaction"""
        try:
            transaction = next((t for t in self.transactions if t["id"] == transaction_id), None)
            if not transaction:
                return False, "Transaction not found"
            
            # Validate and update fields
            valid_fields = {"amount", "category", "description", "date", "tax_notes"}
            for field, value in kwargs.items():
                if field in valid_fields:
                    if field == "amount":
                        value = float(value)
                        if value <= 0:
                            raise ValueError("Amount must be positive")
                    elif field == "category":
                        if value not in self._categories[transaction["type"]]:
                            raise ValueError(f"Invalid category for {transaction['type']}")
                        transaction["tax_category"] = self._get_tax_category(value)
                    
                    transaction[field] = value
            
            transaction["timestamp"] = datetime.now().isoformat()
            self._save_transactions()
            return True, "Transaction updated successfully"
        except ValueError as e:
            return False, str(e)
        except Exception as e:
            return False, f"Failed to edit transaction: {str(e)}"

    def delete_transaction(self, transaction_id):
        """Delete a transaction"""
        try:
            original_count = len(self.transactions)
            self.transactions = [t for t in self.transactions if t["id"] != transaction_id]
            
            if len(self.transactions) < original_count:
                self._save_transactions()
                return True, "Transaction deleted successfully"
            return False, "Transaction not found"
        except Exception as e:
            return False, f"Failed to delete transaction: {str(e)}"

    def get_transaction(self, transaction_id):
        """Get a specific transaction by ID"""
        return next((t for t in self.transactions if t["id"] == transaction_id), None)

    def get_transactions(self, filters=None):
        """Get transactions with optional filtering"""
        if not filters:
            return self.transactions.copy()
        
        filtered = []
        for t in self.transactions:
            match = True
            for key, value in filters.items():
                if key == "date_range":
                    try:
                        t_date = datetime.strptime(t["date"], "%Y-%m-%d").date()
                    except ValueError:
                        # Try alternative format if primary fails
                        try:
                            t_date = datetime.strptime(t["date"], "%Y-%m-%d %H:%M:%S").date()
                        except ValueError:
                            continue
                    
                    if not (value[0] <= t_date <= value[1]):
                        match = False
                        break
                elif key == "amount_range":
                    if not (value[0] <= t["amount"] <= value[1]):
                        match = False
                        break
                elif t.get(key) != value:
                    match = False
                    break
            if match:
                filtered.append(t)
        return filtered

    def get_summary(self, start_date=None, end_date=None):
        """Get comprehensive financial summary"""
        try:
            df = pd.DataFrame(self.transactions)
            
            if df.empty:
                return self._empty_summary()
            
            # Convert and filter dates - handle multiple date formats
            df['date'] = pd.to_datetime(df['date'], errors='coerce')
            df = df.dropna(subset=['date'])
            
            if start_date:
                start_date = pd.to_datetime(start_date)
                df = df[df['date'] >= start_date]
            if end_date:
                end_date = pd.to_datetime(end_date)
                df = df[df['date'] <= end_date]
            
            # Calculate summary statistics
            income_df = df[df['type'] == 'income']
            expense_df = df[df['type'] == 'expense']
            
            summary = {
                "period": {
                    "start": df['date'].min().strftime("%Y-%m-%d") if not df.empty else "",
                    "end": df['date'].max().strftime("%Y-%m-%d") if not df.empty else ""
                },
                "totals": {
                    "income": income_df['amount'].sum(),
                    "expenses": expense_df['amount'].sum(),
                    "net_profit": income_df['amount'].sum() - expense_df['amount'].sum(),
                    "count": len(df)
                },
                "by_category": {
                    "income": income_df.groupby('category')['amount'].sum().to_dict(),
                    "expense": expense_df.groupby('category')['amount'].sum().to_dict()
                },
                "by_tax_category": {
                    "income": income_df.groupby('tax_category')['amount'].sum().to_dict(),
                    "expense": expense_df.groupby('tax_category')['amount'].sum().to_dict()
                },
                "monthly_breakdown": self._get_monthly_breakdown(df),
                "top_transactions": {
                    "largest_income": self._get_largest_transactions(income_df),
                    "largest_expenses": self._get_largest_transactions(expense_df)
                }
            }
            
            return True, summary
        except Exception as e:
            return False, f"Failed to generate summary: {str(e)}"

    def _empty_summary(self):
        """Return empty summary structure"""
        return True, {
            "period": {"start": "", "end": ""},
            "totals": {
                "income": 0,
                "expenses": 0,
                "net_profit": 0,
                "count": 0
            },
            "by_category": {"income": {}, "expense": {}},
            "by_tax_category": {"income": {}, "expense": {}},
            "monthly_breakdown": {},
            "top_transactions": {"largest_income": [], "largest_expenses": []}
        }

    def _get_monthly_breakdown(self, df):
        """Generate monthly breakdown of finances"""
        if df.empty:
            return {}
            
        df['month'] = df['date'].dt.to_period('M')
        monthly = df.groupby(['month', 'type'])['amount'].sum().unstack().fillna(0)
        monthly['profit'] = monthly.get('income', 0) - monthly.get('expense', 0)
        return monthly.to_dict('index')

    def _get_largest_transactions(self, df, n=5):
        """Get the largest n transactions from a dataframe"""
        if df.empty:
            return []
        return (df.nlargest(n, 'amount')[['date', 'amount', 'category', 'description']]
                .to_dict('records'))

    def export_to_excel(self, file_path=None, start_date=None, end_date=None):
        """Export comprehensive financial report to Excel"""
        try:
            if not file_path:
                file_path = os.path.join(self.reports_dir, 
                                       f"financial_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx")
            
            success, summary = self.get_summary(start_date, end_date)
            if not success:
                return False, summary
            
            df = pd.DataFrame(self.get_transactions())
            if start_date or end_date:
                df['date'] = pd.to_datetime(df['date'], errors='coerce')
                df = df.dropna(subset=['date'])
                if start_date:
                    df = df[df['date'] >= pd.to_datetime(start_date)]
                if end_date:
                    df = df[df['date'] <= pd.to_datetime(end_date)]
            
            with pd.ExcelWriter(file_path, engine='xlsxwriter') as writer:
                # Write transactions sheet
                df.to_excel(writer, sheet_name='Transactions', index=False)
                
                # Write summary sheet
                summary_df = pd.DataFrame([
                    ["Total Income", summary["totals"]["income"]],
                    ["Total Expenses", summary["totals"]["expenses"]],
                    ["Net Profit", summary["totals"]["net_profit"]],
                    ["Transaction Count", summary["totals"]["count"]],
                    ["Report Period", f"{summary['period']['start']} to {summary['period']['end']}"]
                ], columns=['Metric', 'Value'])
                summary_df.to_excel(writer, sheet_name='Summary', index=False)
                
                # Write category breakdowns
                income_cats = pd.DataFrame.from_dict(summary["by_category"]["income"], 
                                                   orient='index', columns=['Amount'])
                income_cats.to_excel(writer, sheet_name='Income by Category')
                
                expense_cats = pd.DataFrame.from_dict(summary["by_category"]["expense"], 
                                                    orient='index', columns=['Amount'])
                expense_cats.to_excel(writer, sheet_name='Expenses by Category')
                
                # Write tax information
                tax_info = []
                for tax_cat, amount in summary["by_tax_category"]["expense"].items():
                    tax_info.append([f"Expense: {tax_cat}", amount])
                for tax_cat, amount in summary["by_tax_category"]["income"].items():
                    tax_info.append([f"Income: {tax_cat}", amount])
                
                tax_df = pd.DataFrame(tax_info, columns=['Tax Category', 'Amount'])
                tax_df.to_excel(writer, sheet_name='Tax Information', index=False)
                
                # Create charts
                self._create_excel_charts(writer, summary)
                
            return True, f"Report exported successfully to {file_path}"
        except Exception as e:
            return False, f"Failed to export Excel report: {str(e)}"

    def _create_excel_charts(self, writer, summary):
        """Create charts for Excel report"""
        workbook = writer.book
        
        # Income vs Expenses comparison chart
        chart1 = workbook.add_chart({'type': 'column'})
        chart1.add_series({
            'name': 'Income',
            'categories': '=Summary!$A$2:$A$2',
            'values': '=Summary!$B$2:$B$2',
            'fill': {'color': '#4CAF50'}
        })
        chart1.add_series({
            'name': 'Expenses',
            'categories': '=Summary!$A$3:$A$3',
            'values': '=Summary!$B$3:$B$3',
            'fill': {'color': '#F44336'}
        })
        chart1.set_title({'name': 'Income vs Expenses Comparison'})
        chart1.set_x_axis({'name': 'Category'})
        chart1.set_y_axis({'name': 'Amount'})
        
        # Monthly trend chart
        if summary["monthly_breakdown"]:
            months = sorted(summary["monthly_breakdown"].keys())
            month_names = [str(m) for m in months]
            
            # Prepare data for monthly trend
            income_data = [summary["monthly_breakdown"][m].get('income', 0) for m in months]
            expense_data = [summary["monthly_breakdown"][m].get('expense', 0) for m in months]
            profit_data = [summary["monthly_breakdown"][m].get('profit', 0) for m in months]
            
            # Create a data sheet for the chart
            trend_data = pd.DataFrame({
                'Month': month_names,
                'Income': income_data,
                'Expenses': expense_data,
                'Profit': profit_data
            })
            trend_data.to_excel(writer, sheet_name='Monthly Trends', index=False)
            
            # Create the trend chart
            chart2 = workbook.add_chart({'type': 'line'})
            chart2.add_series({
                'name': '=Monthly Trends!$B$1',
                'categories': '=Monthly Trends!$A$2:$A${}'.format(len(months)+1),
                'values': '=Monthly Trends!$B$2:$B${}'.format(len(months)+1),
                'line': {'color': '#4CAF50', 'width': 3}
            })
            chart2.add_series({
                'name': '=Monthly Trends!$C$1',
                'categories': '=Monthly Trends!$A$2:$A${}'.format(len(months)+1),
                'values': '=Monthly Trends!$C$2:$C${}'.format(len(months)+1),
                'line': {'color': '#F44336', 'width': 3}
            })
            chart2.add_series({
                'name': '=Monthly Trends!$D$1',
                'categories': '=Monthly Trends!$A$2:$A${}'.format(len(months)+1),
                'values': '=Monthly Trends!$D$2:$D${}'.format(len(months)+1),
                'line': {'color': '#2196F3', 'width': 3}
            })
            chart2.set_title({'name': 'Monthly Financial Trends'})
            chart2.set_x_axis({'name': 'Month'})
            chart2.set_y_axis({'name': 'Amount'})
        
        # Category breakdown charts
        chart3 = workbook.add_chart({'type': 'pie'})
        chart3.add_series({
            'name': 'Income by Category',
            'categories': '=Income by Category!$A$2:$A${}'.format(len(summary["by_category"]["income"])+1),
            'values': '=Income by Category!$B$2:$B${}'.format(len(summary["by_category"]["income"])+1),
            'data_labels': {'percentage': True}
        })
        chart3.set_title({'name': 'Income by Category'})
        
        chart4 = workbook.add_chart({'type': 'pie'})
        chart4.add_series({
            'name': 'Expenses by Category',
            'categories': '=Expenses by Category!$A$2:$A${}'.format(len(summary["by_category"]["expense"])+1),
            'values': '=Expenses by Category!$B$2:$B${}'.format(len(summary["by_category"]["expense"])+1),
            'data_labels': {'percentage': True}
        })
        chart4.set_title({'name': 'Expenses by Category'})
        
        # Insert charts into the Summary worksheet
        worksheet = writer.sheets['Summary']
        worksheet.insert_chart('D2', chart1)
        if summary["monthly_breakdown"]:
            worksheet.insert_chart('D20', chart2)
        worksheet.insert_chart('D40', chart3)
        worksheet.insert_chart('L40', chart4)

    def export_to_pdf(self, file_path=None):
        """Export professional PDF report"""
        try:
            if not file_path:
                file_path = os.path.join(self.reports_dir, 
                                       f"financial_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf")
            
            success, summary = self.get_summary()
            if not success:
                return False, summary
            
            # Create PDF
            pdf = FPDF()
            pdf.set_auto_page_break(auto=True, margin=15)
            pdf.add_page()
            
            # Set up title and period
            pdf.set_font('Arial', 'B', 16)
            pdf.cell(0, 10, 'Financial Report', 0, 1, 'C')
            pdf.set_font('Arial', '', 12)
            pdf.cell(0, 10, f"Period: {summary['period']['start']} to {summary['period']['end']}", 0, 1, 'C')
            pdf.ln(10)
            
            # Summary section
            pdf.set_font('Arial', 'B', 14)
            pdf.cell(0, 10, 'Summary', 0, 1)
            pdf.set_font('Arial', '', 12)
            
            # Summary table
            pdf.cell(95, 10, 'Total Income:', 1)
            pdf.cell(95, 10, f"${summary['totals']['income']:,.2f}", 1, 1)
            pdf.cell(95, 10, 'Total Expenses:', 1)
            pdf.cell(95, 10, f"${summary['totals']['expenses']:,.2f}", 1, 1)
            pdf.cell(95, 10, 'Net Profit:', 1)
            pdf.cell(95, 10, f"${summary['totals']['net_profit']:,.2f}", 1, 1)
            pdf.cell(95, 10, 'Transaction Count:', 1)
            pdf.cell(95, 10, str(summary['totals']['count']), 1, 1)
            pdf.ln(15)
            
            # Category breakdowns
            self._add_pdf_category_section(pdf, "Income by Category", summary["by_category"]["income"])
            self._add_pdf_category_section(pdf, "Expenses by Category", summary["by_category"]["expense"])
            
            # Tax information
            pdf.add_page()
            pdf.set_font('Arial', 'B', 14)
            pdf.cell(0, 10, 'Tax Information', 0, 1)
            pdf.set_font('Arial', '', 12)
            
            # Tax categories table
            pdf.cell(95, 10, 'Category', 1)
            pdf.cell(95, 10, 'Amount', 1, 1)
            
            for tax_cat, amount in summary["by_tax_category"]["expense"].items():
                pdf.cell(95, 10, f"Expense: {tax_cat}", 1)
                pdf.cell(95, 10, f"${amount:,.2f}", 1, 1)
            
            for tax_cat, amount in summary["by_tax_category"]["income"].items():
                pdf.cell(95, 10, f"Income: {tax_cat}", 1)
                pdf.cell(95, 10, f"${amount:,.2f}", 1, 1)
            
            # Save PDF
            pdf.output(file_path)
            return True, f"PDF report generated successfully: {file_path}"
        except Exception as e:
            return False, f"Failed to generate PDF report: {str(e)}"

    def _add_pdf_category_section(self, pdf, title, category_data):
        """Add a category breakdown section to the PDF"""
        pdf.add_page()
        pdf.set_font('Arial', 'B', 14)
        pdf.cell(0, 10, title, 0, 1)
        pdf.set_font('Arial', '', 12)
        
        # Category table
        pdf.cell(120, 10, 'Category', 1)
        pdf.cell(70, 10, 'Amount', 1, 1)
        
        for category, amount in category_data.items():
            pdf.cell(120, 10, category, 1)
            pdf.cell(70, 10, f"${amount:,.2f}", 1, 1)
        
        pdf.ln(10)
        
        # Pie chart
        plt.figure(figsize=(6, 6))
        plt.pie(category_data.values(), labels=category_data.keys(), autopct='%1.1f%%')
        plt.title(title)
        chart_path = os.path.join(self.reports_dir, 'temp_chart.png')
        plt.savefig(chart_path, bbox_inches='tight')
        plt.close()
        
        pdf.image(chart_path, x=50, w=100)
        os.remove(chart_path)

    def export_tax_report(self, year=None):
        """Generate a tax-ready report for the given year"""
        try:
            if not year:
                year = datetime.now().year
            
            start_date = f"{year}-01-01"
            end_date = f"{year}-12-31"
            
            file_path = os.path.join(self.reports_dir, f"tax_report_{year}.xlsx")
            
            success, summary = self.get_summary(start_date, end_date)
            if not success:
                return False, summary
            
            with pd.ExcelWriter(file_path, engine='xlsxwriter') as writer:
                # Tax summary sheet
                tax_summary = [
                    ["Tax Year", year],
                    ["Total Taxable Income", summary["by_tax_category"]["income"].get("taxable", 0)],
                    ["Total Deductible Expenses", summary["by_tax_category"]["expense"].get("deductible", 0)],
                    ["Net Taxable Income", 
                     summary["by_tax_category"]["income"].get("taxable", 0) - 
                     summary["by_tax_category"]["expense"].get("deductible", 0)]
                ]
                
                tax_summary_df = pd.DataFrame(tax_summary, columns=['Item', 'Amount'])
                tax_summary_df.to_excel(writer, sheet_name='Tax Summary', index=False)
                
                # Detailed transactions
                transactions = self.get_transactions({
                    "date_range": (
                        datetime.strptime(start_date, "%Y-%m-%d").date(),
                        datetime.strptime(end_date, "%Y-%m-%d").date()
                    )
                })
                
                if transactions:
                    tx_df = pd.DataFrame(transactions)
                    tx_df.to_excel(writer, sheet_name='Transactions', index=False)
                
                # Deductible expenses detail
                deductible_expenses = [t for t in transactions 
                                      if t["type"] == "expense" and t["tax_category"] == "deductible"]
                if deductible_expenses:
                    ded_df = pd.DataFrame(deductible_expenses)
                    ded_df.to_excel(writer, sheet_name='Deductible Expenses', index=False)
                
                # Taxable income detail
                taxable_income = [t for t in transactions 
                                 if t["type"] == "income" and t["tax_category"] == "taxable"]
                if taxable_income:
                    tax_inc_df = pd.DataFrame(taxable_income)
                    tax_inc_df.to_excel(writer, sheet_name='Taxable Income', index=False)
            
            return True, f"Tax report for {year} generated: {file_path}"
        except Exception as e:
            return False, f"Failed to generate tax report: {str(e)}"

    def add_category(self, category_type, category_name, tax_category=None):
        """Add a new category with optional tax classification"""
        try:
            if category_type not in ["income", "expense"]:
                return False, "Invalid category type (must be 'income' or 'expense')"
            
            if category_name in self._categories[category_type]:
                return False, "Category already exists"
            
            self._categories[category_type].append(category_name)
            
            # Save categories
            with open(self.categories_file, 'w') as f:
                json.dump(self._categories, f, indent=4)
            
            # Add tax classification if provided
            if tax_category and tax_category in self.tax_categories:
                self.tax_categories[tax_category].append(category_name)
                with open(self.tax_categories_file, 'w') as f:
                    json.dump(self.tax_categories, f, indent=4)
            
            return True, "Category added successfully"
        except Exception as e:
            return False, f"Failed to add category: {str(e)}"

    def import_from_csv(self, file_path):
        """Import transactions from CSV file"""
        try:
            df = pd.read_csv(file_path)
            required_columns = {'type', 'amount', 'category'}
            if not required_columns.issubset(df.columns):
                return False, f"CSV missing required columns: {required_columns}"
            
            new_transactions = []
            for _, row in df.iterrows():
                result, msg = self.add_transaction(
                    row['type'],
                    row['amount'],
                    row['category'],
                    row.get('description', ''),
                    row.get('date'),
                    row.get('tax_notes', '')
                )
                if not result:
                    return False, f"Failed to import transaction: {msg}"
                new_transactions.append(msg)
            
            return True, f"Successfully imported {len(new_transactions)} transactions"
        except Exception as e:
            return False, f"Failed to import CSV: {str(e)}"

    def generate_monthly_report(self, year, month):
        """Generate a detailed monthly report"""
        try:
            start_date = datetime(year, month, 1).strftime("%Y-%m-%d")
            end_date = datetime(year, month, calendar.monthrange(year, month)[1]).strftime("%Y-%m-%d")
            
            file_path = os.path.join(self.reports_dir, 
                                   f"monthly_report_{year}_{month:02d}.pdf")
            
            success, summary = self.get_summary(start_date, end_date)
            if not success:
                return False, summary
            
            # Create PDF
            pdf = FPDF()
            pdf.set_auto_page_break(auto=True, margin=15)
            pdf.add_page()
            
            # Header
            pdf.set_font('Arial', 'B', 16)
            pdf.cell(0, 10, f"Monthly Financial Report - {calendar.month_name[month]} {year}", 0, 1, 'C')
            pdf.ln(10)
            
            # Summary
            pdf.set_font('Arial', 'B', 14)
            pdf.cell(0, 10, 'Monthly Summary', 0, 1)
            pdf.set_font('Arial', '', 12)
            
            # Summary table
            pdf.cell(95, 10, 'Total Income:', 1)
            pdf.cell(95, 10, f"${summary['totals']['income']:,.2f}", 1, 1)
            pdf.cell(95, 10, 'Total Expenses:', 1)
            pdf.cell(95, 10, f"${summary['totals']['expenses']:,.2f}", 1, 1)
            pdf.cell(95, 10, 'Net Profit:', 1)
            pdf.cell(95, 10, f"${summary['totals']['net_profit']:,.2f}", 1, 1)
            pdf.ln(10)
            
            # Daily breakdown
            transactions = self.get_transactions({
                "date_range": (
                    datetime.strptime(start_date, "%Y-%m-%d").date(),
                    datetime.strptime(end_date, "%Y-%m-%d").date()
                )
            })
            
            if transactions:
                daily_summary = defaultdict(lambda: {'income': 0, 'expense': 0})
                for t in transactions:
                    date = datetime.strptime(t['date'], "%Y-%m-%d %H:%M:%S").date()
                    daily_summary[date][t['type']] += t['amount']
                
                pdf.add_page()
                pdf.set_font('Arial', 'B', 14)
                pdf.cell(0, 10, 'Daily Breakdown', 0, 1)
                pdf.set_font('Arial', '', 12)
                
                # Daily table header
                pdf.cell(60, 10, 'Date', 1)
                pdf.cell(65, 10, 'Income', 1)
                pdf.cell(65, 10, 'Expenses', 1, 1)
                
                # Daily rows
                for date, amounts in sorted(daily_summary.items()):
                    pdf.cell(60, 10, date.strftime("%Y-%m-%d"), 1)
                    pdf.cell(65, 10, f"${amounts['income']:,.2f}", 1)
                    pdf.cell(65, 10, f"${amounts['expense']:,.2f}", 1, 1)
            
            # Save PDF
            pdf.output(file_path)
            return True, f"Monthly report generated: {file_path}"
        except Exception as e:
            return False, f"Failed to generate monthly report: {str(e)}"
