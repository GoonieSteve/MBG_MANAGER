import requests
import socket
import time
import csv
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlparse
from datetime import datetime

try:
    import socks  # For SOCKS proxy support
    SOCKS_SUPPORT = True
except ImportError:
    SOCKS_SUPPORT = False

class ProxyTester:
    def __init__(self, max_threads=10):
        self.max_threads = max_threads
        self.default_timeout = 8
        self.test_url = "https://www.google.com"
        self.proxies = []  # Maintains old format for compatibility
        self.test_results = {}
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Accept": "text/html"
        }
        self.original_socket = socket.socket  # Store original socket

    def add_proxy(self, proxy_str):
        """Add a proxy to the test list"""
        if not any(p['proxy'] == proxy_str for p in self.proxies):
            proxy_data = {
                "proxy": proxy_str,
                "added": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "last_tested": None,
                "status": "untested"
            }
            self.proxies.append(proxy_data)
            return True
        return False

    def _parse_proxy(self, proxy_str):
        """Parse proxy string into components with enhanced parsing"""
        try:
            if proxy_str.startswith(('http://', 'https://', 'socks5://')):
                parsed = urlparse(proxy_str)
                return {
                    "type": "socks5" if "socks5" in proxy_str else "http",
                    "ip": parsed.hostname,
                    "port": parsed.port,
                    "auth": (parsed.username, parsed.password) if parsed.username else None
                }
            else:
                # Handle IP:PORT:USER:PASS format
                parts = proxy_str.split(":")
                if len(parts) == 2:  # IP:Port
                    return {
                        "type": "socks5",
                        "ip": parts[0],
                        "port": int(parts[1]),
                        "auth": None
                    }
                elif len(parts) == 4:  # IP:Port:User:Pass
                    return {
                        "type": "socks5",
                        "ip": parts[0],
                        "port": int(parts[1]),
                        "auth": (parts[2], parts[3])
                    }
                return None
        except:
            return None

    def _test_socks_proxy(self, proxy_info):
        """Test a SOCKS proxy with enhanced checks"""
        if not SOCKS_SUPPORT:
            return {
                "status": "failed",
                "response_time": 0,
                "error": "SOCKS support not available (install PySocks)",
                "anonymity": "unknown"
            }

        result = {
            "status": "failed",
            "response_time": 0,
            "error": "",
            "anonymity": "transparent"
        }

        try:
            # Configure SOCKS
            socks.set_default_proxy(
                socks.SOCKS5,
                proxy_info["ip"],
                proxy_info["port"],
                username=proxy_info["auth"][0] if proxy_info["auth"] else None,
                password=proxy_info["auth"][1] if proxy_info["auth"] else None
            )
            socket.socket = socks.socksocket

            # Test connection
            start = time.time()
            r = requests.get(
                self.test_url,
                headers=self.headers,
                timeout=self.default_timeout
            )
            result["response_time"] = (time.time() - start) * 1000  # in ms
            
            # Anonymity checks
            result["anonymity"] = "elite" if not any(
                h in r.headers for h in ['X-Forwarded-For', 'Via']
            ) else "transparent"
            
            result["status"] = "working"
            
        except Exception as e:
            result["error"] = str(e)
        finally:
            socks.set_default_proxy()  # Reset
            socket.socket = self.original_socket  # Restore original socket
            return result

    def _test_http_proxy(self, proxy_info):
        """Test an HTTP/HTTPS proxy"""
        result = {
            "status": "failed",
            "response_time": 0,
            "error": "",
            "anonymity": "transparent"
        }

        try:
            proxy_url = f"http://{proxy_info['ip']}:{proxy_info['port']}"
            if proxy_info["auth"]:
                proxy_url = f"http://{proxy_info['auth'][0]}:{proxy_info['auth'][1]}@{proxy_info['ip']}:{proxy_info['port']}"

            proxies = {"http": proxy_url, "https": proxy_url}
            start = time.time()
            r = requests.get(
                self.test_url,
                headers=self.headers,
                proxies=proxies,
                timeout=self.default_timeout
            )
            result["response_time"] = (time.time() - start) * 1000  # in ms
            result["anonymity"] = "elite" if 'X-Forwarded-For' not in r.headers else "transparent"
            result["status"] = "working"
        except Exception as e:
            result["error"] = str(e)
        
        return result

    def test_proxy(self, proxy_data, test_url=None):
        """Test a single proxy with enhanced functionality"""
        if test_url:
            self.test_url = test_url

        proxy_str = proxy_data["proxy"]
        proxy_info = self._parse_proxy(proxy_str)
        if not proxy_info:
            return {
                "status": "invalid",
                "response_time": 0,
                "error": "Invalid proxy format",
                "anonymity": "unknown"
            }

        if proxy_info["type"] == "socks5":
            result = self._test_socks_proxy(proxy_info)
        else:
            result = self._test_http_proxy(proxy_info)

        return result

    def test_all_proxies(self, test_url):
        """Test all proxies with threading (maintains old interface)"""
        self.test_url = test_url
        self.test_results = {}

        with ThreadPoolExecutor(max_workers=self.max_threads) as executor:
            futures = {
                executor.submit(self.test_proxy, proxy, test_url): proxy
                for proxy in self.proxies
            }

            for future in as_completed(futures):
                proxy_data = futures[future]
                result = future.result()

                # Update proxy data with test results
                proxy_data.update({
                    "last_tested": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "status": result["status"],
                    "response_time": result.get("response_time", 0),
                    "error": result.get("error", ""),
                    "anonymity": result.get("anonymity", "unknown"),
                    "success_rate": 100 if result["status"] == "working" else 0
                })

                # Store in test results
                self.test_results[proxy_data["proxy"]] = proxy_data

        return self.test_results

    def get_proxy_results(self):
        """Get all proxy test results"""
        return self.test_results

    def get_working_proxies(self):
        """Get only working proxies"""
        return [p for p in self.proxies if p["status"] == "working"]

    def export_results(self, file_path):
        """Export test results to CSV with enhanced data"""
        try:
            with open(file_path, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=[
                    "Proxy", "Status", "Response Time (ms)", 
                    "Success Rate", "Last Tested", "Error", "Anonymity"
                ])
                writer.writeheader()

                for proxy in self.proxies:
                    writer.writerow({
                        "Proxy": proxy["proxy"],
                        "Status": proxy["status"],
                        "Response Time (ms)": proxy.get("response_time", 0),
                        "Success Rate": proxy.get("success_rate", 0),
                        "Last Tested": proxy.get("last_tested", ""),
                        "Error": proxy.get("error", ""),
                        "Anonymity": proxy.get("anonymity", "unknown")
                    })
            return True
        except Exception as e:
            print(f"Export failed: {str(e)}")
            return False
